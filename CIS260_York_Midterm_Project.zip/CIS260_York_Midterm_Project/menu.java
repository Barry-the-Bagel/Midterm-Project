public class menu {
    public static void main(String[] args) throws Exception {
        employee.menu();
    }
}